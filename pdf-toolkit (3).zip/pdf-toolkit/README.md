# PDFKit
Pemotong Skripsi, PDF Tools, dan PDF Playfull (FastAPI + PyMuPDF).

Lokal: `pip install -r requirements.txt` lalu `uvicorn server:app --reload` (buka http://localhost:8000).
Online: push ke GitHub, lalu di Render pilih New > Blueprint (memakai render.yaml).
