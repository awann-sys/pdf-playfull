---
title: PDFKit
emoji: 📄
colorFrom: purple
colorTo: pink
sdk: docker
app_port: 7860
pinned: false
---

PDFKit: Pemotong Skripsi, PDF Tools, dan PDF Playfull (FastAPI + PyMuPDF).
